<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /opt/lampp/htdocs/Rudresh/address-laravel-auth (another copy)/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/header.blade.php ENDPATH**/ ?>