<?php echo e($slot); ?>

<?php /**PATH /home/xceltec-28/Documents/razorpay-laravel/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>