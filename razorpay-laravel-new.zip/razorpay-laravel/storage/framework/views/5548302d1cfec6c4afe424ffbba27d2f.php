<?php $__env->startSection('content'); ?>
<div class="container mx-auto top-0">
    <!-- Breadcrumb Navigation -->
    <div class="flex px-5 py-3 text-gray-700 border border-gray-200 rounded-lg bg-gray-50 dark:bg-gray-800 dark:border-gray-700"
        aria-label="Breadcrumb">
        <ol class="inline-flex items-center space-x-1 md:space-x-2 rtl:space-x-reverse flex-1">
            <!-- Home Breadcrumb -->
            <li class="inline-flex items-center">
                <a href="<?php echo e(route('dashboard')); ?>"
                    class="inline-flex items-center text-sm font-medium text-gray-700 hover:text-blue-600 dark:text-gray-400 dark:hover:text-white">
                    <svg class="w-3 h-3 me-2.5" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"
                        fill="currentColor" viewBox="0 0 20 20">
                        <path
                            d="m19.707 9.293-2-2-7-7a1 1 0 0 0-1.414 0l-7 7-2 2a1 1 0 0 0 1.414 1.414L2 10.414V18a2 2 0 0 0 2 2h3a1 1 0 0 0 1-1v-4a1 1 0 0 1 1-1h2a1 1 0 0 1 1 1v4a1 1 0 0 0 1 1h3a2 2 0 0 0 2-2v-7.586l.293.293a1 1 0 0 0 1.414-1.414Z" />
                    </svg>
                    Home
                </a>
            </li>

            <!-- Separator -->
            <li>
                <div class="flex items-center">
                    <svg class="rtl:rotate-180 block w-3 h-3 mx-1 text-gray-400" aria-hidden="true"
                        xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 6 10">
                        <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="m1 9 4-4-4-4" />
                    </svg>
                    <a href="<?php echo e(route('subcategories.index')); ?>"
                        class="ms-1 text-sm font-medium text-gray-700 hover:text-blue-600 md:ms-2 dark:text-gray-400 dark:hover:text-white">Subcategories</a>
                </div>
            </li>
        </ol>

        <!-- Action Button: Trashed Subcategories aligned at the end -->
        <div class="flex items-center justify-end ml-4 mt-2 md:mt-0">
            <a href="<?php echo e(route('subcategories.deleted')); ?>"
                class="bg-yellow-500 text-white px-3 py-2 rounded-full shadow-md hover:bg-yellow-600 focus:outline-none focus:ring-2 focus:ring-yellow-400 transition duration-300 text-sm">
                Trashed Subcategories
            </a>
        </div>
    </div>

    <!-- Filter Bar -->
    <form action="<?php echo e(route('subcategories.index')); ?>" method="GET"
        class="flex flex-col sm:flex-row justify-between items-center mb-4 bg-gray-50 p-4 rounded-lg shadow-md ">
        <div class="flex space-x-2 w-full max-w-3xl">
            <!-- Search by Subcategory Name -->
            <input type="text" name="search" placeholder="Search by subcategory name..." value="<?php echo e(request()->search); ?>"
                class="px-4 py-2 rounded-md border border-gray-300 focus:outline-none focus:ring-2 focus:ring-blue-400 text-sm w-full sm:w-96">

            <!-- Apply Filters Button -->
            <button type="submit"
                class="bg-blue-500 text-white px-6 py-2 rounded-full hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-400 transition duration-300 text-sm">
                <i class="fas fa-filter"></i>
            </button>
            <!-- Reset Filters Button -->
            <a href="<?php echo e(route('subcategories.index')); ?>"
                class="bg-gray-300 text-black px-6 py-3 rounded-full shadow-md hover:bg-gray-400 focus:outline-none focus:ring-2 focus:ring-gray-400 transition duration-300 flex items-center justify-center text-sm">
                <i class="fas fa-undo"></i>
            </a>
        </div>

        <div class="flex space-x-2 items-center justify-between mt-4 sm:mt-0">
            <!-- Add New Subcategory Button -->
            <a href="<?php echo e(route('subcategories.create')); ?>"
                class="bg-indigo-900 text-white py-2 rounded-full shadow-md hover:bg-indigo-600 focus:outline-none focus:ring-2 focus:ring-indigo-400 transition duration-300 flex items-center justify-center text-sm"
                style="width: 220px;">
                <i class="fas fa-plus-circle mr-2"></i> Create New Subcategory
            </a>
        </div>
    </form>

    <!-- Subcategories Table -->
    <div class="overflow-x-auto bg-white rounded-lg shadow-xl">
        <table class="min-w-full table-auto border-separate border border-gray-200 rounded-lg">
            <thead class="bg-gray-100 text-gray-600">
                <tr>
                    <th class="px-6 py-3 text-center text-sm font-bold">#</th>
                    <th class="px-6 py-3 text-center text-sm font-bold">Subcategory Name</th>
                    <th class="px-6 py-3 text-center text-sm font-bold">Category ID</th>
                    <th class="px-6 py-3 text-center text-sm font-bold">Description</th>
                    <th class="px-6 py-3 text-center text-sm font-bold">Image</th>
                    <th class="px-6 py-3 text-center text-sm font-bold">Actions</th>
                </tr>
            </thead>
            <tbody class="divide-y divide-gray-200">
                <?php $__currentLoopData = $subcategories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subcategory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr class="hover:bg-gray-50 transition-colors duration-200 text-center">
                    <td class="px-6 py-4 text-sm text-gray-800"><?php echo e($subcategory->id); ?></td>
                    <td class="px-6 py-4 text-sm text-gray-800 uppercase font-semibold"><?php echo e($subcategory->name); ?>

                    </td>
                    <td class="px-6 py-4 text-sm text-gray-800">
                        <?php echo e($subcategory->category->name ?? 'No category'); ?>

                    </td>
                    <td class="px-6 py-4 text-sm text-gray-800">
                        <?php echo e($subcategory->description ?? 'No description available'); ?></td>
                    <td class="px-6 py-4 text-sm text-gray-800">
                        <?php if($subcategory->image): ?>
                        <img src="<?php echo e(asset('storage/' . $subcategory->image)); ?>" alt="<?php echo e($subcategory->name); ?> Image"
                            class="w-16 h-16 object-cover rounded-md mx-auto"
                            onerror="this.onerror=null;this.src='<?php echo e(asset('storage/default-image.jpg')); ?>';">
                        <?php else: ?>
                        <span class="text-gray-500">No Image</span>
                        <?php endif; ?>
                    </td>

                    <td class="px-6 py-4 text-sm text-center">
                        <div class="flex justify-center space-x-4">
                            <a href="<?php echo e(route('subcategories.show', $subcategory)); ?>"
                                class="bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600 transition duration-300 flex items-center space-x-2">
                                <i class="fas fa-eye"></i>
                            </a>
                            <a href="<?php echo e(route('subcategories.edit', $subcategory)); ?>"
                                class="bg-blue-500 text-white px-4 py-2 rounded hover:bg-blue-600 transition duration-300 text-sm">
                                <i class="fas fa-edit"></i>
                            </a>
                            <button type="button"
                                class="bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600 transition duration-300 text-sm"
                                onclick="confirmDelete(<?php echo e($subcategory->id); ?>)">
                                <i class="fas fa-trash-alt"></i>
                            </button>
                        </div>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>

    <div class="mt-4 text-sm">
        <?php echo e($subcategories->links()); ?>

        <!-- Pagination Links -->
    </div>
</div>

<!-- Delete Confirmation Modal -->
<div id="deleteModal" class="fixed inset-0 bg-gray-800 bg-opacity-50 flex items-center justify-center hidden">
    <div class="bg-white p-6 rounded-lg shadow-lg max-w-sm w-full">
        <h3 class="text-lg font-semibold text-gray-800 mb-4">Are you sure you want to delete this subcategory?</h3>
        <form id="deleteForm" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <div class="flex justify-end space-x-4">
                <button type="button" onclick="closeModal()"
                    class="bg-gray-300 text-gray-800 px-4 py-2 rounded hover:bg-gray-400 transition duration-300 text-sm">
                    Cancel
                </button>
                <button type="submit"
                    class="bg-red-500 text-white px-4 py-2 rounded hover:bg-red-600 transition duration-300 text-sm">
                    Delete
                </button>
            </div>
        </form>
    </div>
</div>

<script>
    function confirmDelete(subcategoryId) {
            const deleteModal = document.getElementById('deleteModal');
            const deleteForm = document.getElementById('deleteForm');
            deleteForm.action = `/subcategories/${subcategoryId}`;
            deleteModal.classList.remove('hidden');
        }

        function closeModal() {
            const deleteModal = document.getElementById('deleteModal');
            deleteModal.classList.add('hidden');
        }
</script>

<?php if(session('success')): ?>
<div id="successToast"
    class="fixed top-10 right-10 z-50 bg-green-500 text-white px-6 py-3 rounded-md shadow-md flex items-center space-x-3 text-sm">
    <!-- Success Icon -->
    <i class="fas fa-check-circle text-white text-2xl"></i>
    <!-- Success Message -->
    <span><?php echo e(session('success')); ?></span>
</div>

<script>
    setTimeout(() => {
                document.querySelector('#successToast').style.display = 'none';
            }, 4000);
</script>
<?php endif; ?>

<!-- Error Toast -->
<?php if(session('error')): ?>
<div id="errorToast"
    class="fixed top-10 right-10 z-50 bg-red-500 text-white px-6 py-3 rounded-md shadow-md flex items-center space-x-3 text-sm">
    <!-- Error Icon -->
    <i class="fas fa-times-circle text-white text-2xl"></i>
    <!-- Error Message -->
    <span><?php echo e(session('error')); ?></span>
</div>

<script>
    setTimeout(() => {
                document.querySelector('#errorToast').style.display = 'none';
            }, 4000);
</script>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/xceltec-28/Documents/razorpay-laravel/resources/views/subcategories/index.blade.php ENDPATH**/ ?>