<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /opt/lampp/htdocs/Rudresh/razorpay/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/header.blade.php ENDPATH**/ ?>