<?php $__env->startSection('title', 'Checkout'); ?>

<?php $__env->startSection('content'); ?>

<!-- Success Toast -->
<?php if(session('success')): ?>
<div id="successToast"
    class="fixed top-10 right-10 z-50 bg-green-500 text-white px-6 py-3 rounded-lg shadow-lg flex items-center space-x-3">
    <i class="fas fa-check-circle text-white text-2xl"></i>
    <span><?php echo e(session('success')); ?></span>
</div>
<script>
    setTimeout(() => {
        document.querySelector('#successToast').style.display = 'none';
    }, 4000);
</script>
<?php endif; ?>

<!-- Error Toast -->
<?php if(session('error')): ?>
<div id="errorToast"
    class="fixed top-10 right-10 z-50 bg-red-500 text-white px-6 py-3 rounded-lg shadow-lg flex items-center space-x-3">
    <i class="fas fa-times-circle text-white text-2xl"></i>
    <span><?php echo e(session('error')); ?></span>
</div>
<script>
    setTimeout(() => {
        document.querySelector('#errorToast').style.display = 'none';
    }, 4000);
</script>
<?php endif; ?>

<div class="px-4">

    <!-- Cart Items Section -->
    <?php if($cartItems->count() > 0): ?>
    <div class="bg-white shadow-xl rounded-lg p-6 mx-auto mb-4">
        <h2 class="text-3xl font-semibold mb-6 text-gray-800 flex items-center space-x-2">
            <i class="fas fa-cart-arrow-down text-green-500"></i>
            <span>Items in Cart</span>
        </h2>

        <div class="w-full">
            <table class="min-w-full table-auto border-collapse">
                <thead class="bg-gray-50 text-gray-600">
                    <tr>
                        <th class="border px-4 py-3 text-left font-medium text-lg">Product</th>
                        <th class="border px-4 py-3 text-left font-medium text-lg">Price</th>
                        <th class="border px-4 py-3 text-left font-medium text-lg">Quantity</th>
                        <th class="border px-4 py-3 text-left font-medium text-lg">Total</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="hover:bg-gray-50 transition-colors duration-200">
                        <td class="border px-4 py-4 flex items-center space-x-4">
                            <?php
                            $images = explode(',', $item->product->images);
                            ?>
                            <img src="<?php echo e(!empty($images[0]) ? asset('storage/' . trim($images[0])) : asset('images/placeholder.png')); ?>"
                                alt="<?php echo e($item->product->name); ?>" class="w-16 h-16 object-cover rounded-lg shadow-md">
                            <div class="flex flex-col items-start">
                                <span class="text-sm font-medium text-gray-800"><?php echo e($item->product->name); ?></span>
                                <span class="text-sm text-gray-600"><?php echo e($item->product->category->name); ?></span>
                            </div>
                        </td>
                        <td class="border px-4 py-4 text-gray-800 font-semibold">
                            <span class="text-lg">₹</span><?php echo e(number_format($item->product->price, 2)); ?>

                        </td>
                        <td class="border px-4 py-4 text-center">
                            <span class="text-lg font-semibold"><?php echo e($item->quantity); ?></span>
                        </td>
                        <td class="border px-4 py-4 text-gray-800 font-semibold">
                            <span class="text-lg">₹</span><?php echo e(number_format($item->product->price * $item->quantity, 2)); ?>

                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <!-- Shipping Fee Row -->
                    <tr class="bg-gray-100">
                        <td colspan="3" class="border px-4 py-3 text-right font-semibold text-gray-800">Shipping Fee
                        </td>
                        <td class="border px-4 py-3 text-gray-800 font-semibold">
                            <span class="text-lg">₹</span><?php echo e(number_format($shippingFee, 2)); ?>

                        </td>
                    </tr>

                    <!-- Total Amount Row -->
                    <tr class="bg-gray-200">
                        <td colspan="3" class="border px-4 py-3 text-right font-semibold text-gray-800">Total Amount
                        </td>
                        <td class="border px-4 py-3 text-gray-800 font-semibold">
                            <span class="text-lg">₹</span><?php echo e(number_format($finalTotal, 2)); ?>

                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Enter Delivery Address Section -->
    <div class="bg-white shadow-xl rounded-lg p-6" style="overflow: auto;">
        <h2 class="text-3xl font-semibold mb-6 text-gray-800 flex items-center space-x-2">
            <i class="fas fa-map-marker-alt text-blue-500"></i>
            <span>Enter Delivery Address</span>
        </h2>

        <!-- Delivery Address Form -->
        <form action="<?php echo e(route('checkout.process')); ?>" method="POST" id="deliveryForm">
            <?php echo csrf_field(); ?>
            <label for="address" class="block text-lg font-medium mb-2">Address<span
                    class="text-red-500">*</span></label>
            <div class="flex items-center space-x-2 relative">
                <input type="text" id="address" name="address"
                    class="w-full p-4 border bg-gray-200 text-black border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400"
                    placeholder="Your address" required>
                <button type="button" id="locateBtn"
                    class="absolute right-4 top-1/2 transform -translate-y-1/2 p-3 text-2xl text-blue-700 rounded-lg">
                    <i class="fas fa-location-arrow"></i>
                </button>
            </div>
            <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <p class="mt-2 text-sm text-red-500"><?php echo e($message); ?></p>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <div id="map" class="mt-6 w-full" style="height: 450px;"></div>

            <!-- Hidden Fields to Store Latitude and Longitude -->
            <input type="hidden" id="latitude" name="latitude" value="23.024472">
            <input type="hidden" id="longitude" name="longitude" value="72.564500">

            <!-- Payment Methods Header -->
            <div class="mt-8 mb-6">
                <h3 class="text-xl font-semibold">Select Payment Method</h3>
            </div>

            <!-- Payment Options -->
            <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                <!-- Cash on Delivery Option -->
                <div class="bg-gray-100 rounded-lg shadow-md p-6 text-center transition-all">
                    <i class="fas fa-cash-register text-4xl text-green-500"></i>
                    <h4 class="mt-2 font-medium text-lg">Cash on Delivery</h4>
                    <p class="text-gray-600 mt-2">Pay with cash when your order arrives.</p>
                    <button type="submit" name="payment_method" value="cod"
                        class="w-full bg-green-500 text-white px-6 py-3 rounded-md font-medium hover:bg-green-600 transition duration-300 mt-4">
                        <i class="fas fa-cash-register"></i> Choose Cash on Delivery
                    </button>
                </div>


                <!-- Razorpay Payment Option -->
                <div class="bg-gray-100 rounded-lg shadow-md p-6 text-center transition-all">
                    <i class="fab fa-cc-visa text-4xl text-black"></i>
                    <h4 class="mt-2 font-medium text-lg">Pay with Razorpay</h4>
                    <p class="text-gray-600 mt-2">Secure payment via Razorpay.</p>
                    <button type="submit" name="payment_method" value="razorpay"
                        class="w-full bg-yellow-500 text-white px-6 py-3 rounded-md font-medium hover:bg-yellow-600 transition duration-300 mt-4">
                        <i class="fas fa-credit-card"></i> Pay with Razorpay
                    </button>
                </div>
            </div>
        </form>
    </div>
    <?php else: ?>
    <div class="text-center">
        <p class="text-gray-500">No items added yet. Browse and add products to your cart to proceed with checkout.
            <i class="fas fa-cart-arrow-down"></i>
        </p>
    </div>
    <?php endif; ?>

</div>

<!-- Google Maps API Script -->
<script
    src="https://maps.googleapis.com/maps/api/js?v=3.exp&libraries=places&callback=initMap&key=AIzaSyCz7Bo_xQIywAxLvk5BRR5xz70VY2VhLPk"
    async defer></script>

<script>
    let map;
    let geocoder;
    let marker;
    let autocomplete;

    function initMap() {
        if (typeof google === 'undefined') {
            console.error("Google Maps API failed to load.");
            return;
        }

        geocoder = new google.maps.Geocoder();
        const userLocation = {
            lat: 23.024472, // Latitude in decimal degrees
            lng: 72.564500 // Longitude in decimal degrees
        };

        map = new google.maps.Map(document.getElementById('map'), {
            center: userLocation,
            zoom: 14
        });

        marker = new google.maps.Marker({
            position: userLocation,
            map: map,
            title: "Your perfect location"
        });

        document.getElementById('latitude').value = userLocation.lat;
        document.getElementById('longitude').value = userLocation.lng;

        autocomplete = new google.maps.places.Autocomplete(document.getElementById('address'), {
            types: ['geocode'],
        });

        autocomplete.addListener('place_changed', function () {
            const place = autocomplete.getPlace();
            if (!place.geometry) {
                console.error("Place has no geometry");
                return;
            }

            map.setCenter(place.geometry.location);
            marker.setPosition(place.geometry.location);

            document.getElementById('latitude').value = place.geometry.location.lat();
            document.getElementById('longitude').value = place.geometry.location.lng();
            document.getElementById('address').value = place.formatted_address;
        });

        google.maps.event.addListener(map, 'click', function (event) {
            const lat = event.latLng.lat();
            const lng = event.latLng.lng();

            document.getElementById('latitude').value = lat;
            document.getElementById('longitude').value = lng;

            marker.setPosition(event.latLng);

            geocodeLatLng(lat, lng);
        });
    }

    function geocodeLatLng(lat, lng) {
        const latLng = { lat: lat, lng: lng };
        geocoder.geocode({ 'location': latLng }, function (results, status) {
            if (status === 'OK') {
                if (results[0]) {
                    document.getElementById('address').value = results[0].formatted_address;
                } else {
                    alert('No results found');
                }
            } else {
                alert('Geocoder failed due to: ' + status);
            }
        });
    }

    document.getElementById('locateBtn').addEventListener('click', function () {
        if (navigator.geolocation) {
            navigator.geolocation.getCurrentPosition(function (position) {
                const userLat = position.coords.latitude;
                const userLng = position.coords.longitude;
                const userLocation = { lat: userLat, lng: userLng };

                map.setCenter(userLocation);
                marker.setPosition(userLocation);

                document.getElementById('latitude').value = userLat;
                document.getElementById('longitude').value = userLng;

                geocodeLatLng(userLat, userLng);
            });
        } else {
            alert('Geolocation is not supported by this browser.');
        }
    });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/xceltec-28/Documents/razorpay-laravel/resources/views/user/checkout.blade.php ENDPATH**/ ?>