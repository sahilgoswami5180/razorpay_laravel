<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH /home/xceltec-28/Documents/razorpay-laravel/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/header.blade.php ENDPATH**/ ?>