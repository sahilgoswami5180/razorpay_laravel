<?php $__env->startSection('title', 'Your Cart'); ?>

<?php $__env->startSection('content'); ?>
    <!-- Page Header Section -->
    <section id="page-header" class="about-header" style="background-image: url('./img/about/banner.png');">
        <h2>#let's_talk</h2>
        <p>LEAVE A MESSAGE, We love to hear from you!</p>
    </section>

    <!-- Cart Section -->
    <section id="cart" class="section-p1">
        <?php if($cartItems->isEmpty()): ?>
            <!-- Empty Cart Section -->
            <div
                class="max-w-full min-h-[400px] mx-auto bg-gradient-to-r from-blue-100 to-blue-200 shadow-xl rounded-xl p-8 flex flex-col items-center justify-center text-center">
                <i class="fas fa-shopping-cart text-7xl text-gray-600 mb-6 animate-pulse"></i>
                <h2 class="text-2xl sm:text-3xl md:text-xl font-bold text-gray-800 mb-4">Your Cart is Empty</h2>
                <p class="text-gray-600 text-lg mb-6">It appears that you have not added any products to your cart yet.
                    Browse our collection and find something that suits your needs.</p>
                <div class="mt-6">
                    <a href="<?php echo e(route('shop.index')); ?>"
                        class="bg-blue-600 text-white px-8 py-4 rounded-lg hover:bg-blue-700 transition-all duration-300 transform hover:scale-105 flex items-center justify-center space-x-2">
                        <i class="fas fa-arrow-left"></i>
                        <span>Browse Our Products</span>
                    </a>
                </div>
            </div>
        <?php else: ?>
            <!-- Cart Table -->
            <div class="overflow-x-auto">
                <table class="min-w-full">
                    <thead>
                        <tr>
                            <th class="px-4 py-2 text-left">Remove</th>
                            <th class="px-4 py-2 text-left">Image</th>
                            <th class="px-4 py-2 text-left">Product</th>
                            <th class="px-4 py-2 text-left">Price</th>
                            <th class="px-4 py-2 text-left">Quantity</th>
                            <th class="px-4 py-2 text-left">Subtotal</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr id="cart-item-<?php echo e($item->id); ?>">
                                <!-- Remove Button -->
                                <td class="px-4 py-2">
                                    <form action="<?php echo e(route('cart.remove', $item)); ?>" method="POST" class="inline">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit"
                                            class="text-red-400 bg-white border-2 border-red-400 px-4 py-2 rounded-md hover:text-white hover:bg-red-400">
                                            <i class="fas fa-times-circle"></i>
                                        </button>
                                    </form>
                                </td>

                                <!-- Product Image -->
                                <td class="px-4 py-2">
                                    <?php
                                        $images = explode(',', $item->product->images);
                                    ?>
                                    <img src="<?php echo e(asset('storage/' . trim($images[0]))); ?>"
                                        alt="<?php echo e($item->product->name); ?> - Image" class="w-20 h-20 object-cover rounded-lg">
                                </td>

                                <!-- Product Name -->
                                <td class="px-4 py-2" style="white-space: normal; word-wrap: break-word;">
                                    <?php echo e(Str::limit($item->product->name, 55, '...')); ?>

                                </td>

                                <!-- Product Price -->
                                <td class="px-4 py-2">₹<?php echo e(number_format($item->product->price, 2)); ?></td>

                                <!-- Quantity Input -->
                                <td class="px-4 py-2">
                                    <form action="<?php echo e(route('cart.updateQuantity', $item)); ?>" method="POST" class="inline">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PATCH'); ?>
                                        <button type="submit" name="quantity" value="<?php echo e($item->quantity - 1); ?>"
                                            class="w-8 h-8 bg-red-500 text-white font-semibold rounded-l-md hover:bg-red-600 focus:outline-none focus:ring-2 focus:ring-red-500 focus:ring-opacity-50"
                                            <?php echo e($item->quantity <= 1 ? 'disabled' : ''); ?>>
                                            <i class='bx bxs-minus-circle'></i>
                                        </button>

                                        <span
                                            class="w-16 text-center py-1 border-t border-b rounded-md bg-gray-100 inline-block"><?php echo e($item->quantity); ?></span>

                                        <button type="submit" name="quantity" value="<?php echo e($item->quantity + 1); ?>"
                                            class="w-8 h-8 bg-green-500 text-white font-semibold rounded-r-md hover:bg-green-600 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-opacity-50">
                                            <i class='bx bxs-plus-circle'></i>
                                        </button>
                                    </form>
                                </td>

                                <!-- Subtotal -->
                                <td class="px-4 py-2">₹<?php echo e(number_format($item->product->price * $item->quantity, 2)); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </section>

    <!-- Cart Add Section: Coupon & Total -->
    <section id="cart-add" class="section-p1">
        <div id="coupon">
            <h3>Apply Coupon</h3>
            <div>
                <input type="text" placeholder="Enter Your Coupon" class="border p-2 rounded-lg w-2/3">
                <button
                    class="normal px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-all">Apply</button>
            </div>
        </div>

        <div id="subtotal">
            <h3>Cart Total</h3>
            <table>
                <tr>
                    <td>Cart Subtotal</td>
                    <td>₹<?php echo e(number_format($cartItems->sum(fn($item) => $item->product->price * $item->quantity), 2)); ?></td>
                </tr>
                <tr>
                    <td>Shipping</td>
                    <td>Free</td>
                </tr>
                <tr>
                    <td><strong>Total</strong></td>
                    <td><strong>₹<?php echo e(number_format($cartItems->sum(fn($item) => $item->product->price * $item->quantity), 2)); ?></strong>
                    </td>
                </tr>
            </table>
            <a href="<?php echo e(route('user.checkout')); ?>"
                class="normal px-8 py-3 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-all">Proceed to
                Checkout</a>
        </div>
    </section>

    <!-- Toast Notifications -->
    <?php if(session('success')): ?>
        <div id="successToast"
            class="fixed top-10 right-10 z-50 bg-green-500 text-white px-6 py-3 rounded-md shadow-md flex items-center space-x-3">
            <i class="fas fa-check-circle text-white text-2xl"></i>
            <span><?php echo e(session('success')); ?></span>
        </div>
        <script>
            setTimeout(() => {
                document.querySelector('#successToast').style.display = 'none';
            }, 4000);
        </script>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div id="errorToast"
            class="fixed top-10 right-10 z-50 bg-red-500 text-white px-6 py-3 rounded-md shadow-md flex items-center space-x-3">
            <i class="fas fa-times-circle text-white text-2xl"></i>
            <span><?php echo e(session('error')); ?></span>
        </div>
        <script>
            setTimeout(() => {
                document.querySelector('#errorToast').style.display = 'none';
            }, 4000);
        </script>
    <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /opt/lampp/htdocs/Rudresh/address-laravel-auth/resources/views/user/cart.blade.php ENDPATH**/ ?>