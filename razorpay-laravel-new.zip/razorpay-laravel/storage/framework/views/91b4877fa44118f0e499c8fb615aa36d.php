<?php echo e($slot); ?>

<?php /**PATH /opt/lampp/htdocs/Rudresh/razorpay/vendor/laravel/framework/src/Illuminate/Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>