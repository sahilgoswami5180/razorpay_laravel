@extends('layouts.user')

@section('content')
    <style>
        .custom-scrollbar::-webkit-scrollbar {
            width: 10px;
            /* Width of the scrollbar */
        }

        .custom-scrollbar::-webkit-scrollbar-track {
            background: #f1f1f1;
            /* Track color */
        }

        .custom-scrollbar::-webkit-scrollbar-thumb {
            background: #888;
            /* Thumb color */
            border-radius: 10px;
        }

        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
            background: #555;
            /* Thumb color on hover */
        }

        /* For Firefox */
        .custom-scrollbar {
            scrollbar-width: thin;
            scrollbar-color: #888 #f1f1f1;
        }
    </style>
    <div
        class="bg-gray-100 shadow-lg flex flex-col md:flex-row items-start justify-center w-full min-h-screen p-6 pt-2 space-y-6 md:space-y-0 md:space-x-6">
        <!-- Left Side: Previous Messages and Admin Replies -->
        <div
            class="custom-scrollbar bg-white shadow-lg rounded-lg p-6 w-full md:w-1/2 max-w-2xl flex-1 max-h-screen overflow-y-auto">

            <h2 class="text-2xl md:text-3xl font-semibold text-center text-gray-700 mb-6">Your Previous Messages</h2>

            @foreach ($contactUsSubmissions as $message)
                <div class="bg-gray-50 p-6 rounded-lg mb-6 shadow-md hover:shadow-lg transition-all duration-300">
                    <div class="text-xl font-semibold text-gray-800">{{ $message->name }}</div>
                    <div class="text-sm text-gray-500">{{ $message->created_at->format('M d, Y h:i A') }}</div>
                    <div class="mt-3 text-gray-700">{{ $message->message }}</div>

                    <!-- Admin Reply -->
                    @if ($message->replies->isNotEmpty())
                        <div class="replies-container mt-5 p-4 bg-blue-50 rounded-md shadow-md">
                            <div class="text-blue-600 font-semibold">Admin Replies:</div>
                            @foreach ($message->replies as $reply)
                                <div class="reply-item mt-3 bg-blue-100 p-4 rounded-md text-gray-700">
                                    <div class="flex justify-between">
                                        <span class="font-semibold text-blue-600">Admin Reply:</span>
                                        <span
                                            class="text-xs text-gray-500">{{ $reply->created_at->format('Y-m-d H:i:s') }}</span>
                                    </div>
                                    <div class="text-gray-700">{{ Str::limit($reply->message, 50) }}</div>
                                    <div class="full-reply mt-3 hidden bg-blue-100 p-4 rounded-md text-gray-700"
                                        id="reply-{{ $message->id }}">
                                        <p>{{ $reply->message }}</p>
                                    </div>
                                </div>
                            @endforeach
                        </div>
                    @else
                        <p class="mt-3 text-gray-500">No reply from the admin yet.</p>
                    @endif

                </div>
            @endforeach
        </div>

        <!-- Right Side: Contact Form -->
        <div class="bg-white shadow-lg rounded-lg p-6 w-full md:w-1/2 max-w-full flex-1 max-h-screen overflow-y-auto">
            <h2 class="text-2xl md:text-3xl font-semibold text-center text-gray-700 mb-6">Contact Us</h2>

            <!-- Success Toast -->
            @if (session('success'))
                <div id="successToast"
                    class="fixed top-10 right-10 z-50 bg-green-500 text-white px-6 py-3 rounded-lg shadow-lg flex items-center space-x-3">
                    <i class="fas fa-check-circle text-white text-2xl"></i>
                    <span>{{ session('success') }}</span>
                </div>
                <script>
                    setTimeout(() => {
                        document.querySelector('#successToast').style.display = 'none';
                    }, 4000);
                </script>
            @endif

            <!-- Error Toast -->
            @if (session('error'))
                <div id="errorToast"
                    class="fixed top-10 right-10 z-50 bg-red-500 text-white px-6 py-3 rounded-lg shadow-lg flex items-center space-x-3">
                    <i class="fas fa-times-circle text-white text-2xl"></i>
                    <span>{{ session('error') }}</span>
                </div>
                <script>
                    setTimeout(() => {
                        document.querySelector('#errorToast').style.display = 'none';
                    }, 4000);
                </script>
            @endif

            <!-- Form Start -->
            <form action="{{ url('/contact-us') }}" method="POST">
                @csrf

                <!-- Name Field -->
                <div class="mb-6">
                    <label for="name" class="block text-sm font-medium text-gray-700">Name <span
                            class="text-red-500">*</span></label>
                    <div class="relative">
                        <input type="text" name="name" id="name"
                            class="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                            required>
                        <i
                            class="fas fa-user absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 text-lg"></i>
                    </div>
                </div>

                <!-- Email Field -->
                <div class="mb-6">
                    <label for="email" class="block text-sm font-medium text-gray-700">Email <span
                            class="text-red-500">*</span></label>
                    <div class="relative">
                        <input type="email" name="email" id="email"
                            class="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                            required>
                        <i
                            class="fas fa-envelope absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 text-lg"></i>
                    </div>
                </div>

                <!-- Message Field -->
                <div class="mb-6">
                    <label for="message" class="block text-sm font-medium text-gray-700">Message <span
                            class="text-red-500">*</span></label>
                    <div class="relative">
                        <textarea name="message" id="message"
                            class="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-2 focus:ring-blue-500"
                            rows="5" required></textarea>
                        <i
                            class="fas fa-comment-alt absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 text-lg"></i>
                    </div>
                </div>

                <!-- Submit Button -->
                <button type="submit" class="w-full bg-blue-500 text-white py-2 rounded-md hover:bg-blue-600 transition">
                    <i class="fas fa-paper-plane mr-2"></i> Send Message
                </button>
            </form>

            <!-- Back Link -->
            <div class="mt-4 text-center">
                <a href="{{ url('/') }}" class="text-blue-500 hover:underline text-sm">
                    <i class="fas fa-home mr-1"></i> Back to Home
                </a>
            </div>
        </div>
    </div>

    <script>
        // Hide toast notifications after 4 seconds
        setTimeout(() => {
            document.querySelector('#successToast')?.style.display = 'none';
            document.querySelector('#errorToast')?.style.display = 'none';
        }, 4000);

        // Toggle full reply visibility
        document.querySelectorAll('.view-reply-btn').forEach(button => {
            button.addEventListener('click', function() {
                const messageId = this.dataset.messageId;
                const replyDiv = document.querySelector(`#reply-${messageId}`);
                replyDiv.classList.toggle('hidden');
                // Toggle button text between 'View' and 'Hide'
                this.textContent = replyDiv.classList.contains('hidden') ? 'View' : 'Hide';
            });
        });
    </script>
@endsection
