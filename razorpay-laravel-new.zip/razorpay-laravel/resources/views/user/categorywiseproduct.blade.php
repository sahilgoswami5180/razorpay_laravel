@extends('layouts.user')

@section('title', 'E-commerce Shopping | Products Category Wise')

@section('content')

<!-- Back Icon -->
<section class="py-4 bg-gray-100">
    <div class="container mx-auto">
        <a href="{{ url()->previous() }}" class="flex items-center text-blue-500 hover:text-blue-600 font-medium">
            <i class="fas fa-arrow-left mr-2"></i> Back
        </a>
    </div>
</section>

<!-- Category Products Section -->
<section class="py-12 bg-gray-100">
    <div class="container mx-auto text-center">
        <h2 class="text-2xl font-bold text-gray-800 mb-6">Products in {{ $category->name }}</h2>

        <!-- Grid of Products -->
        <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            @foreach ($products as $product)
            @php
            // Check if the product is in the cart
            $cartItem = session('cart')[$product->id] ?? null;
            @endphp

            <div class="bg-white p-4 rounded-md shadow-lg transform hover:scale-105 transition-transform duration-300">
                <img src="{{ asset('storage/' . $product->image) }}" alt="{{ $product->name }}"
                    class="w-full h-48 object-cover rounded-md mb-4">
                <h3 class="text-xl font-semibold text-gray-800">{{ $product->name }}</h3>
                <p class="text-gray-600 mt-2">{{ Str::limit($product->description, 100) }}</p>
                <p class="text-lg font-bold text-blue-500 mt-4">${{ number_format($product->price, 2) }}</p>

                @if ($cartItem)

                <!-- Product is in the cart, show update and remove buttons -->
                <div class="mt-4">
                    <!-- Remove Button -->
                    <form action="{{ route('cart.remove', $product) }}" method="POST" class="inline">
                        @csrf
                        @method('DELETE')
                        <button type="submit" class="text-red-500 flex items-center space-x-2 hover:text-red-700">
                            <i class="fas fa-trash-alt"></i>
                            <span>Remove</span>
                        </button>
                    </form>

                    <!-- Update Quantity with + and - buttons -->
                    <form action="{{ route('cart.updateQuantity', $product) }}" method="POST" class="inline">
                        @csrf
                        @method('PATCH')
                        <div class="space-y-2">
                            <!-- Quantity Input (on its own line) -->
                            <input type="number" name="quantity" value="{{ $cartItem['quantity'] }}" min="1"
                                class="w-20 text-center border border-gray-300 rounded-md mx-auto block" readonly>

                            <!-- Container for buttons -->
                            <div class="flex space-x-2 mt-2">
                                <!-- Decrease Button -->
                                <button type="submit" name="quantity" value="{{ $cartItem['quantity'] - 1 }}"
                                    class="bg-gray-200 text-gray-600 px-3 py-1 rounded-md hover:bg-gray-300 w-20 flex items-center justify-center"
                                    {{ $cartItem['quantity'] <=1 ? 'disabled' : '' }}>
                                    <i class="fas fa-minus"></i>
                                </button>

                                <!-- Increase Button -->
                                <button type="submit" name="quantity" value="{{ $cartItem['quantity'] + 1 }}"
                                    class="bg-gray-200 text-gray-600 px-3 py-1 rounded-md hover:bg-gray-300 w-20 flex items-center justify-center">
                                    <i class="fas fa-plus"></i>
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
                @else
                <!-- Add to Cart Button -->
                <div class="mt-4">
                    <form action="{{ route('cart.add', $product) }}" method="POST">
                        @csrf
                        <button type="submit"
                            class="bg-blue-500 text-white px-6 py-2 rounded-md font-medium hover:bg-blue-600">Add to
                            Cart</button>
                    </form>
                </div>
                @endif
            </div>
            @endforeach
        </div>
    </div>
</section>

@endsection
