$orderDet = new OrdersDetails();
$orderDet->user_id = '0';
$orderDet->guest_id = $request['user_id'];
$orderDet->order_id = $order_id;
// $orderDet->kds_id = $synced_kds_ids;
$orderDet->menu_id = $value->menu_id;
$orderDet->size_id = $value->size_id;
$orderDet->cat_id = $FindCategoryId->menu_category_id;
$orderDet->sub_cat_id = $findmenu->sub_category_id;
if (isset($depart_id->department_id)) {
$orderDet->department_id = $depart_id->department_id;
                                }
                                $orderDet->menu_name = $findmenu->menu_name;
                                $orderDet->menu_price = $servingPrice;
                                $orderDet->menu_price_final = $servingPrice * $value->quantity;
                                $orderDet->menu_discount_price_final = $discountPrice * $value->quantity;

                                // $d_tax = [];
                                // foreach ($request['item'] as $key => $item) {
                                //     $i_tax = $item->tax_amount;
                                //     $d_tax[] = $i_tax;
                                // }
                                // dump($d_tax);

                                // for tax inclusive start
                                if ($request['tax_inclusive'] == 'Y') {
                                    foreach ($request['item'] as $key => $value) {
                                       
                                        $orderDet->menu_discount_price = $value->discount_price; 
                                    }

                                    // $orderDet->menu_discount_price = $discountPrice;
                                } else {
                                    $orderDet->menu_discount_price = $discountPrice;
                                }
                                //end

                                if ($taxess != "") {
                                    // $orderDet->taxs = $taxess . ',' . $moditx;
                                    $orderDet->taxs = $taxess;

                                } else {
                                    // $orderDet->taxs = $moditx;
                                }
                                // $orderDet->tax_amount = $total_tax;
                                $orderDet->tax_amount = $itemTax;

                                $orderDet->notes = $notes;
                                $orderDet->quantity = $value->quantity;
                                $orderDet->created_by = $request['user_id'];
                                $orderDet->created_date = $time_now;
                                $orderDet->timezone = $request['timezone'];
                                //$orderDet->updated_by = $request['user_id'];
                                $orderDet->updated_date = $time_now;
                                //$orderDet->ip_address = \Request::ip();
                                $orderDet->is_priority = 'N';
                                $orderDet->item_status = 'Ordered';
                                $orderDet->center_edge_discount = number_format((float) $centeredgediscountAmt, 2);
                                $orderDet->center_edge_discount_id = $centerDisId;
                                $orderDet->restaurant_id = $request['restaurant_id'];
                                $orderDet->restaurant_branch_id = $request['branch_id'];
                                $orderDet->save();