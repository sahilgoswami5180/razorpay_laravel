$orderDet = new OrdersDetails();
$orderDet->user_id = '0';
$orderDet->guest_id = $request['user_id'];
$orderDet->order_id = $order_id;
// $orderDet->kds_id = $synced_kds_ids;
$orderDet->menu_id = $value->menu_id;
$orderDet->size_id = $value->size_id;
$orderDet->cat_id = $FindCategoryId->menu_category_id;
$orderDet->sub_cat_id = $findmenu->sub_category_id;

if (isset($depart_id->department_id)) {
    $orderDet->department_id = $depart_id->department_id;
}

$orderDet->menu_name = $findmenu->menu_name;
$orderDet->menu_price = $servingPrice;
$orderDet->menu_price_final = $servingPrice * $value->quantity;
$orderDet->menu_discount_price_final = $discountPrice * $value->quantity;

// Handle tax inclusive logic
if ($request['tax_inclusive'] == 'Y') {
    foreach ($request['item'] as $key => $value) {
        // Ensure tax is included in the price
        $orderDet->menu_discount_price = $value->discount_price;
    }
} else {
    // For non-tax-inclusive, set the discount price
    $orderDet->menu_discount_price = $discountPrice;
}

if ($taxess != "") {
    // Only assign $taxess once to avoid duplication
    $orderDet->taxs = $taxess;
}

$orderDet->notes = $notes;
$orderDet->quantity = $value->quantity;
$orderDet->created_by = $request['user_id'];
$orderDet->created_date = $time_now;
$orderDet->timezone = $request['timezone'];
$orderDet->updated_date = $time_now;
// $orderDet->ip_address = \Request::ip();
$orderDet->is_priority = 'N';
$orderDet->item_status = 'Ordered';
$orderDet->center_edge_discount = number_format((float) $centeredgediscountAmt, 2);
$orderDet->center_edge_discount_id = $centerDisId;
$orderDet->restaurant_id = $request['restaurant_id'];
$orderDet->restaurant_branch_id = $request['branch_id'];

// Only assign the tax amount once here
$orderDet->tax_amount = $itemTax; // Assign tax amount just once

// Save the order details
$orderDet->save();
