<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up()
    {
        Schema::table('orders', function (Blueprint $table) {
            $table->string('razorpay_payment_id')->nullable();  // Payment ID from Razorpay
            $table->string('razorpay_order_id')->nullable();    // Order ID from Razorpay
            $table->string('razorpay_signature')->nullable();   // Signature for verifying payment
        });
    }

    public function down()
    {
        Schema::table('orders', function (Blueprint $table) {
            $table->dropColumn(['razorpay_payment_id', 'razorpay_order_id', 'razorpay_signature']);
        });
    }
};