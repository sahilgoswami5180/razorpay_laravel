<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddPaymentColumnsToOrdersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('orders', function (Blueprint $table) {
            $table->string('payment_status')->default('pending');  // Track payment status: pending, successful, failed
            $table->string('payment_method')->nullable();  // Payment method (razorpay, cod, etc.)
            $table->text('payment_details')->nullable();  // Store JSON of payment details (payment ID, order ID, etc.)
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('orders', function (Blueprint $table) {
            $table->dropColumn('payment_status');
            $table->dropColumn('payment_method');
            $table->dropColumn('payment_details');
        });
    }
}