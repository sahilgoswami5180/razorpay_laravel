<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up()
    {
        Schema::create('orders', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->onDelete('cascade');
            $table->text('product_id')->nullable(); // Changed from foreignId to text to store comma-separated product IDs
            $table->decimal('total', 8, 2);
            $table->string('status')->default('pending');
            $table->text('order_items')->nullable(); // Column to store comma-separated order items
            $table->text('order_images')->nullable(); // Column to store comma-separated order images
            $table->text('order_quantities')->nullable(); // Column to store comma-separated quantities
            $table->text('order_prices')->nullable(); // Column to store comma-separated prices
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('orders');
    }
};